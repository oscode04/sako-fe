// checkup/view/CheckupView.jsx

import React, { useState } from "react";
import Navbar from "../../component/Navbar";
import Stepper from "../../component/Stepper";
import CheckupModel from "./CheckupModel";
import CheckupPresenter from "./CheckupPresenter";

const CheckupView = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState(CheckupModel.initialData);
  // eslint-disable-next-line no-unused-vars
  const { handleChange, handleNumericBlur } = CheckupPresenter(
    formData,
    setFormData
  );

  const Input = ({ label, name, placeholder = "", prefix = "" }) => {
    const [inputValue, setInputValue] = useState(formData[name]);

    const onInputChange = (e) => setInputValue(e.target.value);

    const onInputBlur = () => {
      const cleaned = handleNumericBlur(name, inputValue);
      setInputValue(cleaned);
    };

    const isPengeluaran = name === "pengeluaran";

    return (
      <div className="mb-4">
        <label className="block text-gray-700 font-medium mb-1">{label}</label>
        <div className="flex">
          {prefix && (
            <span
              className={`px-3 py-2 border border-r-0 rounded-l-md ${
                isPengeluaran
                  ? "bg-[#f1f1f1] text-[#204842] border-[#BBF49D]"
                  : "bg-gray-100"
              }`}
            >
              {prefix}
            </span>
          )}
          <input
            name={name}
            type="text"
            inputMode="numeric"
            className={`w-full px-3 py-2 border focus:outline-none focus:ring-2 ${
              prefix ? "rounded-r-md border-l-0" : "rounded-md"
            } ${
              isPengeluaran
                ? "bg-[#BBF49D] text-[#204842] border-[#BBF49D] focus:ring-[#BBF49D]"
                : "focus:ring-green-300"
            }`}
            placeholder={placeholder}
            value={inputValue}
            onChange={onInputChange}
            onBlur={onInputBlur}
          />
        </div>
      </div>
    );
  };

  // Komponen Select dan renderForm seperti sebelumnya (bisa dipisah juga kalau perlu)

  const renderForm = () => {
    switch (step) {
      case 1:
        return (
          <>
            <Input
              label="Nama"
              name="nama"
              placeholder="Masukkan nama lengkap"
            />
            <Input label="Usia" name="usia" placeholder="Masukkan usia" />
            <Input
              label="Pekerjaan"
              name="pekerjaan"
              placeholder="Masukkan pekerjaan"
            />
          </>
        );
      case 2:
        return (
          <>
            <Input
              label="Pendapatan"
              name="pendapatan"
              prefix="Rp"
              placeholder="contoh: 5000000"
            />
            <Input
              label="Tanggungan"
              name="tanggungan"
              placeholder="contoh: 2"
            />
          </>
        );
      case 3:
        return (
          <>
            <Input label="Kebutuhan Pokok" name="kebutuhan_pokok" prefix="Rp" />
            <Input label="Tempat Tinggal" name="tempat_tinggal" prefix="Rp" />
            <Input label="Transportasi" name="transportasi" prefix="Rp" />
          </>
        );
      case 4:
        return (
          <>
            <Input label="Pendidikan" name="pendidikan" prefix="Rp" />
            <Input label="Kesehatan" name="kesehatan" prefix="Rp" />
            <Input label="Komunikasi" name="komunikasi" prefix="Rp" />
          </>
        );
      case 5:
        return (
          <>
            <Input label="Hiburan" name="hiburan" prefix="Rp" />
            <Input label="Donasi" name="donasi" prefix="Rp" />
            <Input label="Tidak Terduga" name="tidak_terduga" prefix="Rp" />
            <Input label="Lainnya" name="lainnya" prefix="Rp" />
            <Input label="Total Pengeluaran" name="pengeluaran" prefix="Rp" />
          </>
        );
      default:
        return null;
    }
  };

  // Navigasi next or before
  const nextStep = () => step < 5 && setStep(step + 1);
  const prevStep = () => step > 1 && setStep(step - 1);

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-[#f6fdf6] py-8 px-4">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md p-6">
          <h2 className="text-2xl font-semibold text-center text-green-900 mb-2">
            Finansial check up
          </h2>
          <p className="text-center text-gray-600 mb-6">
            Luangkan beberapa menit untuk mengetahui kesehatan keuanganmu.
          </p>
          <Stepper activeStep={step} />

          {/* renderForm(step, Input, Select, formData, handleChange) */}
          <div className="mt-6 min-h-[320px]">{renderForm()}</div>

          {/* Navigasi : Next : Before */}
          <div className="flex justify-between mt-6">
            {step > 1 ? (
              <button
                onClick={prevStep}
                className="bg-[#f1f8f4] text-gray-700 px-4 py-2 rounded-lg"
              >
                Sebelumnya
              </button>
            ) : (
              <div />
            )}
            <button
              onClick={step === 5 ? () => alert("Data terkirim!") : nextStep}
              style={{ backgroundColor: "#BBF49D", color: "#204842" }}
              className="px-4 py-2 rounded-lg hover:brightness-90"
            >
              {step === 5 ? "Kirim" : "Selanjutnya"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default CheckupView;
